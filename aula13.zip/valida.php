<?php
session_start();

require_once("Banco.php");

$banco = new Banco();

// var_dump($_GET );

$email = $_GET['email'];
$senha = $_GET['password'];

/// está sujeito a sql injection
$sql = "select email, senha from usuario_2021 where email='$email' and senha='$senha'";
$resultado = $banco->query($sql);

if ( $resultado->rowCount() > 0 ) {
    // echo "sucesso";
    $_SESSION['autorizado']=true;
    header('Location: https://aula-php-andre-eppinghaus.000webhostapp.com/2021-1/aula-terca/aula13/menu.php');
}else{
    unset( $_SESSION['autorizado']);

    header('Location: https://aula-php-andre-eppinghaus.000webhostapp.com/2021-1/aula-terca/aula13/index.php?erro=1');
}
?>