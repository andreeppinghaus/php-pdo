<?php

$user = "id13482607_root";
$pass = ")?SJ4)|}nV</DG}9";
try {
    $pdo = new PDO('mysql:host=localhost;dbname=id13482607_aula_php', $user, $pass);
    
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}


function consulta($pdo) {
    foreach($pdo->query('SELECT * from usuario_2021') as $row) {
        echo "<br>id = ".$row["id"]."<br>";
        echo "<br>email = ".$row["email"]."<br>";
        echo "<br>senha = ".$row["senha"]."<br>";
        echo "<br>==================<br>";
        // var_dump($row);
    }
    $pdo = null;
}



function incluir($pdo, $email, $senha) {
    
    
    $sql = "insert into usuario_2021(email, senha) values('$email', '$senha')";
    $pdo->exec($sql);
    
    
}


incluir($pdo, "rodrigo@teste.net", "999");

consulta($pdo);


?>