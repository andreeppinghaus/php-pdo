<html>
    <head><title>Tela de login e senha</title></head>
    <body>
        <form action="valida.php" method="get">
            <label>Email</label>
            <input type="email" name="email" >
            <br><br>
            <label>Senha</label>
            <input type="text" name="password" >
            <br><br>
            <input type="submit">
        </form>
        <?php
        if (isset($_GET['erro']) ) {
            echo "<p>Login ou senha inválidos</p>";
        }
        ?>
    </body>
</html>