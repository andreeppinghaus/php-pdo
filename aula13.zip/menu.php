<?php
session_start();
if (! isset($_SESSION["autorizado"])) {
    header('Location: https://aula-php-andre-eppinghaus.000webhostapp.com/2021-1/aula-terca/aula13/index.php');
}
echo "<h1>Tela principal do sistema</h1>";