<?php


class Banco {
    private $pdo;
   
    public function __construct(){
        $user = "usuario";
        $pass = "senhadobanco";

        try {
            
            $this->pdo = new PDO('mysql:host=localhost;dbname=id13482607_aula_php', 
                                  $user, $pass);   
        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
     
    }
    
    public function query($sql) {
        return $this->pdo->query($sql);
    }
    
    public function exec($sql) {
        return $this->pdo->exec($sql);
    }
}


?>